// @ts-check

/**
 * An object with ESLint options.
 * @type {import('eslint').Linter.Config}
 */
module.exports = require('../../.eslintrc.json');
