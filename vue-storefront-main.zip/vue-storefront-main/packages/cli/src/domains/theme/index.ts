export { default as inheritTheme } from './inheritTheme';
