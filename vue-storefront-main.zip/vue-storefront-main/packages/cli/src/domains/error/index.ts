export { default as resolveToError } from './resolveToError';
