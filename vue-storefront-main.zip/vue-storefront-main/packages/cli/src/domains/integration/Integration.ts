type Integration = {
  name: string;
  gitRepositoryURL: string;
  documentationURL?: string;
};

export default Integration;
