export const success = () => {
  return {
    status: 200,
    message: 'ok',
    error: false
  };
};
