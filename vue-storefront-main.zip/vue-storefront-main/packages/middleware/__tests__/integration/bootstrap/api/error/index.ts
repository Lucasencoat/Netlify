export const error = () => {
  return {
    status: 404,
    message: 'error',
    error: true
  };
};
