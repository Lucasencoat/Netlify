import pkg from './package.json';
import { generateBaseConfig } from '../rollup.base.config';

export default generateBaseConfig(pkg);
