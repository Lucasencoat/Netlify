export interface HttpCacheModuleParams {
  default?: string
  matchRoute?: {
    [key: string]: string
  }
}
