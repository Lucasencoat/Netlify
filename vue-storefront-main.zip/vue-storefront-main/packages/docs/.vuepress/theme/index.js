module.exports = {
  extend: 'vsf-docs',
};
