# Does Vue Storefront support Static-Site Generation?

No, at this moment, Vue Storefront only works as a Server-Side Rendered (SSR) application.

We plan to add support for Static-Site Generation in the future, but it's not on our immediate roadmap.
