# Frequently Asked Questions

- [Does Vue Storefront use Vue 3/Nuxt 3?](/faq/vue3.html)
- [Does Vue Storefront support Static-Site Generation?](/faq/ssg.html)
