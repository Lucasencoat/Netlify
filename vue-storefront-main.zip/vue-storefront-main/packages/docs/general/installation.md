Moved to [Installation](/getting-started/installation.html)
