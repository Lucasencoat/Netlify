export default {
  routes: true
};
