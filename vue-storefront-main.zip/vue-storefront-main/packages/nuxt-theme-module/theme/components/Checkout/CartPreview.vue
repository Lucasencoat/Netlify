<template>
  <b>Please implement vendor-specific CartPreview component in the 'components/Checkout' directory</b>
</template>

<script>
export default {
  name: 'CartPreview'
};
</script>
