<template>
  <b>Please implement vendor-specific UserShippingAddress component in the 'components' directory</b>
</template>

<script>
export default {
  name: 'UserShippingAddress'
};
</script>
