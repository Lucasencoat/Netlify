<template>
  <b>Please implement vendor-specific PasswordResetForm component in the 'components/MyAccount' directory</b>
</template>

<script>
export default {
  name: 'PasswordResetForm'
};
</script>
