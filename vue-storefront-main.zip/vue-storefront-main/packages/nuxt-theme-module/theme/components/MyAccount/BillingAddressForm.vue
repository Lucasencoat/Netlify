<template>
  <b>Please implement vendor-specific BillingAddressForm component in the 'components/MyAccount' directory</b>
</template>

<script>
export default {
  name: 'BillingAddressForm'
};
</script>
