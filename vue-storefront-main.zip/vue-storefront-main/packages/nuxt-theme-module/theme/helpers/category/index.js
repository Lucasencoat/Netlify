import { getCategorySearchParameters } from './getCategorySearchParameters';
import { getCategoryPath } from './getCategoryPath';

// TODO: remove, use faceting instead
export {
  getCategorySearchParameters,
  getCategoryPath
};
